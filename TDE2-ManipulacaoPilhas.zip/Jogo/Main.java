import java.util.Scanner;
import java.awt.SystemColor;
import java.util.Random;
import Jogo.Pilha;

class Main {
  
  //Utilizando o conceito de pilha e lista haverão 3 pilhas para manipulação
  //precisam estar no escopo global
  private static Pilha stack1;
  private static Pilha stack2;
  private static Pilha stack3;
  private static int stackSize;
  private static int orderChoice;
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    //Quando o jogo abrir será solicitado o tamanho das pilhas.
    System.out.println("Escolha o tamanho das pilhas: ");
    stackSize = scanner.nextInt();
      
     // Inicialize as pilhas globalmente
    stack1 = fillWithRandomNumbers();
    stack2 = new Pilha();
    stack3 = new Pilha();
   
     //o jogo imprime as 3 pilhas e passa o controle ao jogador.
    printStacks(stack1,stack2,stack3);
    printMenu();

    //fazer a contagem das vezes que jogou
    Integer countMovedPeaces = 0;
    
    while (true) {

      int escolha = scanner.nextInt();
      
      switch (escolha) {
        case 0:
          System.out.println("Jogo encerrado.");
          System.exit(0);
          break;
        case 1:
          System.out.println("Escolha a ordem para verificar (1 - Crescente, 2 - Decrescente):");
          orderChoice = scanner.nextInt();
          //fique verificando, a cada jogada, se alguma pilha está cheia e, caso positivo, se está ordenada. 
          if (verifyOrderedStacks(stack1, stack2, stack3) == false){
            ///funcao que pede as pilhas a serem movimentadas e movimenta as peças
            moveDisk(countMovedPeaces); 
          }
          
          break;
        case 2:
          automaticResolution();
          System.out.println("Nova ordenação das pilhas: ");
          printStacks(stack1,stack2,stack3);
          System.exit(0);
          break;
        default:
          System.out.println("Opção inválida. Tente novamente.");
        }
      }
    }

  public static void moveDisk(Integer countMovedPeaces){

    if (verifyOrderedStacks(stack1, stack2, stack3) == false){
      Scanner scanner = new Scanner(System.in);
      
      System.out.print("Digite o número da pilha de origem (1, 2 ou 3): ");
      int origin = scanner.nextInt();
      Pilha originStack = getStackByNumber(origin);
      
      System.out.print("Digite o número da pilha de destino (1, 2 ou 3): ");
      int destiny = scanner.nextInt();
      Pilha destinyStack = getStackByNumber(destiny);
      
      try{
        // a funcao remove retorna um node
        int movedObject = originStack.remove();
        System.out.println(movedObject);
        destinyStack.inserir(movedObject);
        countMovedPeaces++;
        printStacks(stack1,stack2,stack3);
        //System.out.println("CoundMovedPeaces" + countMovedPeaces);
        moveDisk(countMovedPeaces);
      }
      catch (NullPointerException e) {
        System.out.println("Escolha outra pilha de origem pois esta está vazia :) /n");
        moveDisk(countMovedPeaces);
      }
      
    } else{
      System.out.println("O jogo foi vencido com " + countMovedPeaces +  " movimentos." );
    }
    
  }
  
  //O jogo inicia com o preenchimento da pilha1 com números aleatórios na faixa de 1 a 100
  public static Pilha fillWithRandomNumbers(){
    Random random = new Random();
    Pilha stack = new Pilha();

    for(int i=0; i<stackSize; i++){
      int aleatoryNumber = random.nextInt(101);
      stack.inserir(aleatoryNumber);
    }
    return stack;
  }

  public static void printStacks(Pilha p1,Pilha p2,Pilha p3){
    System.out.println("Pilha 1: ");
    p1.imprime();
    
    System.out.println("Pilha 2: ");
    p2.imprime();
    
    System.out.println("Pilha 3: ");
    p3.imprime();
  }

  public static void printMenu(){
    System.out.println("Escolha uma opção:");
    System.out.println("0 - Sair do jogo");
    System.out.println("1 - Movimentar");
    System.out.println("2 - Solução automática");
  }
  
  public static Pilha getStackByNumber(int number) {
    switch(number) {
      case 1:
        return stack1;
      case 2:
        return stack2;
      case 3:
        return stack3;
      default:
        return null; 
    }
  }

  public static Boolean verifyOrderedStacks(Pilha stack1, Pilha stack2, Pilha stack3 ){
    switch(orderChoice){
      case 1:
        if (stack1.isSortedAscending(stackSize) || stack2.isSortedAscending(stackSize) ||stack3.isSortedAscending(stackSize) ){
          return true;
        }
        return false;
        
      case 2:
        if (stack1.isSortedDescending(stackSize) || stack2.isSortedDescending(stackSize) || stack3.isSortedDescending(stackSize)){
          return true;
        }
        return false;
        
      default:
        return  false;
    }
  }
  
  public static void automaticResolution() {
    // Move elements from stack2 and stack3 to stack1
    while (stack2.countElements() != 0) {
        stack1.inserir(stack2.remove());
    }

    while (stack3.countElements() != 0) {
        stack1.inserir(stack3.remove());
    }

    stack2.inserir(stack1.remove());
    
    while (!verifyOrderedStacks(stack1, stack2, stack3)) {
        while (stack2.countElements() != 0) {
          if (stack2.getTopo().getInformacao() > stack1.getTopo().getInformacao()) {
            break;
          }
          stack3.inserir(stack2.remove());
        }
        stack2.inserir(stack1.remove());

        while (stack3.countElements() != 0) {
            stack2.inserir(stack3.remove());
        }
    }
  }
}