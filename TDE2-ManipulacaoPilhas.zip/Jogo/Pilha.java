 package Jogo;

import java.util.Scanner;

//utilização do algoritmo implementado no ultimo TDE e validado com nota máxima pelo professor
public class Pilha {
  private Node Topo;

  public Pilha() {
    this.Topo = null;
  }

  public Integer getInformacao(){
    return this.Topo.getInformacao();
  }

  public Node getTopo(){
    return this.Topo;
  }
  
  // Inserindo elementos
  public void inserir(int informacao) {
    // Declarando nosso novo nó
    Node no = new Node();

    no.setInformacao(informacao);
    if (Topo == null) {
      Topo = no;
    } else {
      no.setProximo(Topo);
      Topo = no;
    }
  }

  // sempre remove do ultimo indice, vulgo ultimo elemento a ser colocado na pilha
  public Integer remove() {
    Node topo = Topo;
    Integer informacaoRemovida = topo.getInformacao();
    
    Topo = topo.getProximo();
    topo = null;

    return informacaoRemovida;
  }

  // Imprimindo elementos
  public void imprime() {
    Node atual = Topo;

    if(atual == null){
      System.out.println("Pilha vazia :(");
    }
      
    else{
      while (atual != null) {
      System.out.print(atual.getInformacao() + " -> ");
      atual = atual.getProximo();
      }

      System.out.println("Acabou");
    }
  }

  public int countElements() {
    int count = 0;
    Node atual = Topo;

    while (atual != null) {
        count++;
        atual = atual.getProximo();
    }

    return count;
  }
  public boolean isSortedAscending(int stackSize){
    int countingElements = 1;  // 

    // 
    if(Topo == null || Topo.getProximo() == null){ 
      return false;
    }

    Node atual = Topo;

    while(atual.getProximo() != null){  // 
      
      // 
      if(atual.getInformacao() > atual.getProximo().getInformacao()){
        return false;
      }
      atual = atual.getProximo();
      countingElements++;
    }
    System.out.println("Contagem de elementos: " + countingElements);

    // 
    return countingElements == stackSize;
}


  
  public boolean isSortedDescending(int stackSize){
    int countingElements = 1;  // 

    // 
    if(Topo == null || Topo.getProximo() == null){ 
      return false;
    }

    Node atual = Topo;

    while(atual.getProximo() != null){  // 
      
      // 
      if(atual.getInformacao() < atual.getProximo().getInformacao()){
        return false;
      }
      atual = atual.getProximo();
      countingElements++;
    }
  
    return countingElements == stackSize;
}

  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Pilha pilha = new Pilha();

    System.out.println("Digite os itens da lista (digite '0' para parar):");
    int item;
    while (true) {
      item = scanner.nextInt();
      if (item == 0) {
        break;
      }
      pilha.inserir(item);
    }
    scanner.close();

    System.out.println("Lista Encadeada:");
    pilha.imprime();
    pilha.remove();
    System.out.println("pilha após remover o primeiro elemento ");
    pilha.imprime();

  }
}
